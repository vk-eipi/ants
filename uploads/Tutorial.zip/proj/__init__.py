#!/usr/bin/env python
from ants import Ants
